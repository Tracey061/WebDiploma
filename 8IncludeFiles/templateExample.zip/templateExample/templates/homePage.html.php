<section id="column1">
    <h1>Lorem Ispsum Life</h1>
    <h2>Surfing Lessons</h2>
    <?= $date ?>
    <p>Lorem sit amet consectetur adipisicing elit. Veritatis eligendi officiis accusantium voluptates laborum doloremque expedita necessitatibus incidunt dolor, aliquam esse voluptatum, quae ipsum itaque minus alias ipsa totam. Unde..</p>
    <img src="images/surf.jpg" width="500" height="273" alt="surfing">
    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ducimus vel iste facere nobis sapiente neque molestias ab vitae, aperiam dolorum in nostrum hic repellat optio laboriosam, accusantium ipsam fugiat soluta.
    </p>
</section>
<section id="column2">
    <h2>Art classes</h2>
    <img src="images/art.jpg" width="500" height="298" alt="art">
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique itaque possimus aperiam nulla molestiae impedit iusto illum expedita. <a href="index.html">Earum sint excepturi</a> voluptates nihil optio! Maiores commodi incidunt delectus cum expedita!</p>
</section>