<section id="column1">
    <h1>Contact</h1>
    <?= $year ?>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor autem consequatur libero sed sint nemo exercitationem tempore hic nulla aperiam et aut, commodi, voluptas iste ut excepturi veniam culpa voluptatum!</p>

</section>
<section id="column2">
    <h2>Heading </h2>
    <img src="images/coffee.jpg" width="490" height="339" alt="Coffee">
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique itaque possimus aperiam nulla molestiae impedit iusto illum expedita. <a href="">Earum sint excepturi</a> voluptates nihil optio! Maiores commodi incidunt delectus cum expedita!</p>
</section>