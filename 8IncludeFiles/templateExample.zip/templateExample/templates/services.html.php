<section id="column1">
    <h1>Services</h1>
    <p>Lorem sit amet consectetur adipisicing elit. Veritatis eligendi officiis accusantium voluptates laborum doloremque expedita necessitatibus incidunt dolor, aliquam esse voluptatum, quae ipsum itaque minus alias ipsa totam. Unde..</p>
    
    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ducimus vel iste facere nobis sapiente neque molestias ab vitae, aperiam dolorum in nostrum hic repellat optio laboriosam, accusantium ipsam fugiat soluta.
    </p>
</section>
<section id="column2">
    <h2>Heading here</h2>
    <?= $date ?>
    <img src="images/lake.jpg" width="500" height="333" alt="Lake">
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique itaque possimus aperiam nulla molestiae impedit iusto illum expedita. <a href="">Earum sint excepturi</a> voluptates nihil optio! Maiores commodi incidunt delectus cum expedita!</p>
</section>