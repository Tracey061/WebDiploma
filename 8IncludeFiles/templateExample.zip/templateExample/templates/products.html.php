<section id="column1">
    <h1>Products</h1>
    <p>Lorem <a href="">ipsum dolor</a> sit amet consectetur adipisicing elit. Veritatis eligendi officiis accusantium voluptates laborum doloremque expedita necessitatibus incidunt dolor, aliquam esse voluptatum, quae ipsum itaque minus alias ipsa totam. Unde..</p>
    <img src="images/weights.jpg" width="500" height="273" alt="weights">
    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ducimus vel iste facere nobis sapiente neque molestias ab vitae, aperiam dolorum in nostrum hic repellat optio laboriosam, accusantium ipsam fugiat soluta.
    </p>
</section>
<section id="column2">
    <h2>Something here</h2>
    <?= $productDate ?>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique itaque possimus aperiam nulla molestiae impedit iusto illum expedita. <a href="">Earum sint excepturi</a> voluptates nihil optio! Maiores commodi incidunt delectus cum expedita!</p>
</section>